# football-players-detection > 2025-09-20 12:32pm
https://universe.roboflow.com/anushspvtworkspace/football-players-detection-3zvbc-gmjzv

Provided by a Roboflow user
License: CC BY 4.0

